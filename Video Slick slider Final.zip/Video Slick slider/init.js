var slideWrapper = $('.home-slide');
  function videoStat(slick) {
    var currentSlide = slick.find(".slick-current");
    var slideType = currentSlide.attr('data-slide-type');
    if (slideType === "youtube") {
      var pl = currentSlide.find("iframe").get(0);
      var fid = $(pl).attr('id');
      var ik_player = new YT.Player(fid);
      ik_player.addEventListener("onStateChange", function(state){
        if(state.data == 0 || state.data == 2){
          slideWrapper.slick("slickNext");
          slideWrapper.slick('slickPlay');
        }
      });
    } else if (slideType === "hvideo") {
      var pl = currentSlide.find("video").get(0);
      pl.onended = function(e) {
        slideWrapper.slick("slickNext");
        slideWrapper.slick('slickPlay');
      };
      pl.onpause = function() {
        slideWrapper.slick("slickNext");
        slideWrapper.slick('slickPlay');
      }; 
    }
  }

  function postMessageToPlayer(player, command){
    if (player == null || command == null) return;
    player.contentWindow.postMessage(JSON.stringify(command), "*");
  }

  function playPauseVideo(slick, control){
    var currentSlide, slideType, startTime, player, video;
    currentSlide = slick.find(".slick-current");
    slideType = currentSlide.attr('data-slide-type');
    player = currentSlide.find("iframe").get(0);
    startTime = currentSlide.data("video-start");
    if (slideType === "youtube") {
      switch (control) {
        case "play":
          slideWrapper.slick('slickPause');
          postMessageToPlayer(player, {
            "event": "command",
            "func": "mute"
          });
          postMessageToPlayer(player, {
            "event": "command",
            "func": "playVideo"
          });
          break;
        case "pause":
          postMessageToPlayer(player, {
            "event": "command",
            "func": "pauseVideo"
          });
          break;
      }
    } else if (slideType === "hvideo") {
      video = currentSlide.find("video").get(0);
      if (video != null) {
        if (control === "play"){
          slideWrapper.slick('slickPause');
          video.play();
        } else {
          video.pause();
          slideWrapper.slick("slickNext");
          slideWrapper.slick('slickPlay');
        }
      }
    }
    else if (slideType === "vimeo") {
      switch (control) {
        case "play":
          if ((startTime != null && startTime > 0 ) && !currentSlide.hasClass('started')) {
            currentSlide.addClass('started');
            postMessageToPlayer(player, {
              "method": "setCurrentTime",
              "value" : startTime
            });
          }
          postMessageToPlayer(player, {
            "method": "play",
            "value" : 1
          });
          break;
        case "pause":
          postMessageToPlayer(player, {
            "method": "pause",
            "value": 1
          });
          break;
      }
    }
  }
  slideWrapper.on("beforeChange", function(event, slick) {
    slick = $(slick.$slider);
    playPauseVideo(slick,"pause");
  });
  slideWrapper.on("afterChange", function(event, slick) {
    slick = $(slick.$slider);
    playPauseVideo(slick,"play");
    videoStat(slick);
  });

  slideWrapper.on("init", function(slick){
    slick = $(slick.currentTarget);
    setTimeout(function(){
      playPauseVideo(slick,"play");
      videoStat(slick);
    }, 2000);
  });
  $('.home-slide').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    dots: true,
    autoplay: true,
    adaptiveHeight: true
  });